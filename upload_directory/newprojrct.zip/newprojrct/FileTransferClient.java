import java.io.*;
import java.net.*;

public class FileTransferClient {
    private String serverAddress;
    private int port;

    public FileTransferClient(String serverAddress, int port) {
        this.serverAddress = serverAddress;
        this.port = port;
    }

    public void uploadFileData(File file, String owner) {
        if (file == null || !file.exists()) {
            System.out.println("File not found: " + file.getAbsolutePath());
            return;
        }

        try (Socket socket = new Socket(serverAddress, port);
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
             FileInputStream fis = new FileInputStream(file)) {

            // Send file details
            dos.writeUTF(file.getName());
            dos.writeLong(file.length());
            dos.writeUTF(owner); // Send owner information

            // Send file data
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) > 0) {
                dos.write(buffer, 0, bytesRead);
            }

            System.out.println("File uploaded successfully: " + file.getName());

        } catch (IOException ex) {
            System.err.println("Error uploading file: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void downloadFile(String filename, String savePath) {
        try (Socket socket = new Socket(serverAddress, port);
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
             DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            // Request file download
            dos.writeUTF("DOWNLOAD");
            dos.writeUTF(filename);

            // Receive response
            boolean fileExists = dis.readBoolean();
            if (!fileExists) {
                System.out.println("File not found on server: " + filename);
                return;
            }

            // Receive and save file
            File file = new File(savePath);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = dis.read(buffer)) > 0) {
                    fos.write(buffer, 0, bytesRead);
                }
            }

            System.out.println("File downloaded successfully: " + savePath);

        } catch (IOException ex) {
            System.err.println("Error downloading file: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void deleteFile(String filename, String owner) {
        try (Socket socket = new Socket(serverAddress, port);
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

            // Request file deletion
            dos.writeUTF("DELETE");
            dos.writeUTF(filename);
            dos.writeUTF(owner);

            System.out.println("File deletion request sent for: " + filename);

        } catch (IOException ex) {
            System.err.println("Error deleting file: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}

