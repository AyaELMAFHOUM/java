import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PortSelection {
    private JFrame frame;
    private JTextField portField;

    public void display() {
        frame = new JFrame("Select Server Port");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));

        JLabel portLabel = new JLabel("Server Port:");
        portField = new JTextField("8080"); // Default port

        JButton startButton = new JButton("Start Server");
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int port = Integer.parseInt(portField.getText());
                    frame.dispose();
                    new AdminDashboard(port); // Initialize the admin dashboard with the selected port
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid port number!", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Error starting server: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });

        panel.add(portLabel);
        panel.add(portField);
        panel.add(new JLabel());
        panel.add(startButton);

        frame.add(panel);
        frame.setVisible(true);
    }
}
