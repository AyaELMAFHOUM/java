import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;

public class FileTransferServer {
    private int port;
    private AdminDashboard adminDashboard;

    public FileTransferServer(int port) {
        this.port = port;
        try {
            this.adminDashboard = new AdminDashboard(port); // Pass the port to AdminDashboard
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception appropriately
            System.exit(1); // Optionally terminate the application if the dashboard fails to initialize
        }
    }

    public void start() {
        System.out.println("Server started on port: " + port);
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                // Handle client in a separate thread
                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleClient(Socket clientSocket) {
        try (ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream())) {
            FileMetadata fileMetadata = (FileMetadata) ois.readObject();
            saveFileToDatabase(fileMetadata);

            // Simulate refreshing the file list in the admin dashboard
            List<FileMetadata> temporaryFileList = fetchFilesFromDatabase();
            adminDashboard.refreshFileList(temporaryFileList);

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void saveFileToDatabase(FileMetadata file) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/file_transfer", "root", "hhaamiidd");
             PreparedStatement ps = conn.prepareStatement("INSERT INTO files (filename, owner, upload_date) VALUES (?, ?, ?)")) {

            ps.setString(1, file.getFilename());
            ps.setString(2, file.getOwner());
            ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            ps.executeUpdate();

            System.out.println("File saved to database: " + file.getFilename());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private List<FileMetadata> fetchFilesFromDatabase() {
        List<FileMetadata> fileList = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/file_transfer", "root", "hhaamiidd");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT filename, owner, upload_date FROM files")) {

            while (rs.next()) {
                fileList.add(new FileMetadata(rs.getString("filename"), rs.getString("owner"), rs.getTimestamp("upload_date")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fileList;
    }
}

