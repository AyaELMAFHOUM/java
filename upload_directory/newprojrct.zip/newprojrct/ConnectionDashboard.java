import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;

class ConnectionDashboard {
    JFrame frame;
    String username;

    public ConnectionDashboard(String username) {
        this.username = username;
    }

    public void display() {
        frame = new JFrame("Connect to Server");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        JLabel ipLabel = new JLabel("Server IP:");
        JTextField ipField = new JTextField("127.0.0.1"); // Default IP
        JLabel portLabel = new JLabel("Server Port:");
        JTextField portField = new JTextField("8080"); // Default Port

        JButton connectButton = new JButton("Connect");
        connectButton.addActionListener(e -> {
            try {
                // Directly proceed to the UserDashboard since FileTransferClient handles database connection
                frame.dispose();
                new UserDashboard(username).display(); // Pass only the username
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error connecting to server.", "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        panel.add(ipLabel);
        panel.add(ipField);
        panel.add(portLabel);
        panel.add(portField);
        panel.add(new JLabel());
        panel.add(connectButton);

        frame.add(panel);
        frame.setVisible(true);
    }
}
