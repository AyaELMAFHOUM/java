import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
// ClientMain.java - Main class for Client Application
public class ClientMain {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserLogin userLogin = new UserLogin();
            userLogin.display();
        });
    }
}